// Polyfill for browser API
if (typeof browser === "undefined") {
  var browser = chrome;
}

// WordGlow Background Script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "translate" && message.text) {
    const apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
      message.text
    )}&langpair=en|ar`;

    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        const translation = data?.responseData?.translatedText;
        if (translation) {
          sendResponse({ translation });
        } else {
          sendResponse({ translation: null, error: "No translation found." });
        }
      })
      .catch((error) => {
        sendResponse({
          translation: null,
          error: error.message || "Translation failed.",
        });
      });
    return true;
  }
});
